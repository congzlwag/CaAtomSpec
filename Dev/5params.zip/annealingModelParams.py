# -*- coding: utf-8 -*-
import numpy as np
from numpy import random as rdm
from specPreProcess import cm_1_to_eV
from sys import path
path.append("./build/lib.linux-x86_64-3.6/")
from numerov import eigE
import time

paramss = np.array([[  4.0099,   2.1315,  13.023 ,   0.    ,   1.6352],
		    		[  4.2056,   2.0186,  12.658 ,   0.    ,   1.5177],
		    		[  3.5058,   2.2648,  12.399 ,   0.    ,   1.6187],
		    		[  3.7741,   3.1848,  13.232 ,   0.    ,   0.715 ],
		    		[  3.6   ,   2.3   ,  12.8   ,   0.    ,   0.8   ]])

datae = np.load('specs/CaII.npz')

def Diff(l,n_,j_,e_,params,dx=1e-3):
	N = n_.size
	assert N==j_.size and N==e_.size
	a1,a2,a3,a4,rc = params
	resid = np.array([e_[k]-eigE(l,j_[k],e_[k], a1, a2, a3, a4, rc, dx, n_[k]*2*(n_[k]+15)) for k in range(N)])
	return resid

def Loss(l,n_,j_,e_,params,dx=1e-3):
	resid = Diff(l,n_,j_,e_,params,dx)
	return (resid**2).sum()

def SimAnnealParams(l,T=.5,Tdecay=0.97,h_params=np.ones(paramss.shape[1])*0.05,n_iter=50):
	sd = 1
	rdm.seed(sd)
	fp = open("AnnealLog/%d/%s.log"%(l,time.strftime("%m_%d_%Y-%H%M", time.localtime(int(time.time())))), 'w')
	print("seed\th",file=fp)
	print("%d\t"%sd+"%.2f\t%.2f\t%.2f\t%.2f\t%.2f"%tuple(h_params),file=fp)
	params = paramss[l]
	data = datae[str(l)]
	los = Loss(l, data['n'],data['j'],data['energy/eV'], params)
	kkk = 0
	print("#%d loss=%.5f"%(kkk,los), "(%.4f,%.4f,%.4f,%.4f,%.4f)"%tuple(params), "T=%.2g"%T)
	print("#%d loss=%.5f"%(kkk,los), "(%.4f,%.4f,%.4f,%.4f,%.4f)"%tuple(params), "T=%.2g"%T, file=fp)
	kkk += 1
	while True:
		kkk_ = kkk+n_iter
		while kkk < kkk_:
			steps= (2*rdm.rand(params.size)-1)*h_params
			los_ = Loss(l, data['n'],data['j'],data['energy/eV'], params+steps)
			if los_<los or (los_>los and rdm.rand() < np.exp((los-los_)/T)):
				params += steps
				los = los_
			print("#%d loss=%.5f"%(kkk,los), "(%.4f,%.4f,%.4f,%.4f,%.4f)"%tuple(params), "T=%.2g"%T)
			print("#%d loss=%.5f"%(kkk,los), "(%.4f,%.4f,%.4f,%.4f,%.4f)"%tuple(params), "T=%.2g"%T,file=fp)
			T *= Tdecay
			kkk += 1
		instruct = input("Continue for another %d iteration? (y/n)"%n_iter)
		if not (instruct=='y' or instruct=='Y'):
			break
	fp.close()

if __name__ == '__main__':
	pass
	# SimAnnealParams(0,5,.95,n_iter=100)
	# e_est = datae['0']
	# print(eigE(0,0.5,,))