#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_9_API_VERSION
#include <numpy/arrayobject.h>

#include <iostream>
#include <Vec.h>
#include <tridiag.h>
#include <cmath>
// #include <fstream>
// #include <string>
#include <stdio.h>
#include <cstdlib>
// #include <random>

#define INVPOW_MAXITER 50
#define SIMANN_MAXITER 100

int Z = 20, CoreValency = 2;
double alphaD = 3.26, alpha2 = 5.325135447834466e-5;
size_t l=0;
double j=0.5, mu=0.9999862724756698;
// to ignore SOC, set j<0
double SoL=0.5*(j*(j+1)-l*(l+1)-0.75), hfL2=0.5*l*(l+1);

double dx, rmax, xmin;
double dx2t2o3;
size_t n_samp=0;
// Vec<double> r_, xpot_, f_;

// parameters in the modeled potential
double a1,a2,a3,a4,rc;

// std::vector<double> jl,el;
// void readCaIILevels(size_t L, std::vector<double> & J, std::vector<double> & E, bool verbose=false);

double invPower(const Triband<double> & T, Vec<double> & V, const Triband<double> & pM, double eval0, double rtol);
double eigen(const size_t & L, const double & J, double Einit, double _a1, double _a2, double _a3, double _a4, double _rc);
// void simAnnealModelParams(size_t L, double beta=1., double decay=0.8, double h_a1=.02, double h_a2=.02, double h_a3=.02, double h_a4=.02, double h_rc=.02);

static PyObject * NumerovEigE(PyObject * self, PyObject * args){
	double einit;
	if(!(PyArg_ParseTuple(args,"iddddddddd",
		&l, &j, &einit,&a1,&a2,&a3,&a4,&rc,&dx,&rmax)))
		return NULL;
	// Triband<double> tri(5);
	// tri.d.setAll(1.0);
	// tri.pu.setAll(0.1);
	// tri.pd.setAll(-0.2);
	// Triband<double> t2(tri);
	double e = eigen(l,j,einit,a1,a2,a3,a4,rc);
	return Py_BuildValue("d", e);
}
// int main(){
// 	// Triband<double> t1(3);
// 	// t1.d.setAll(0.5);
// 	// t1.pu.setAll(0.7);
// 	// t1.pd.setAll(-0.3);
// 	// Vec<double> v1(3,1.0);
// 	// Triband<double> M(Vec<double>(3,1.),Vec<double>(2,0.),Vec<double>(2,0.));
// 	// M.d[0]=3;
// 	// M.d[1]=1;
// 	// M.d[2]=4;
// 	// M.pu[0]=-0.1;
// 	// double ev=invPower(t1,v1,&M,0.1414,1e-10);
// 	// std::cout<<ev<<std::endl;
// 	// std::cout<<v1;
	

// 	simAnnealModelParams(0, 1.);
// 	// dx = 1e-3;
// 	// rmax = 150;
// 	// double en = eigen(0,0.5,-3.1088,4.0099,  2.1315, 13.023 ,  0.    ,  1.6352);
// 	// std::cout<<en<<"n_samp="<<n_samp;
// 	return 0;
// }

double radEffPot(double r){
	/*
	Radial Effective Potential
	Veff^{(lj)}(r) = U(r) + \frac{l(l+1)}{2\mu r} + \frac{\alpha^2}{4}(j(j+1)-l(l+1)-s(s+1))\frac{d U(r)}{r dr}
	*/
	double effCharge,res,ddrEffCharge,aCovr5,xi,rovrc6;
	rovrc6 = pow(r/rc,6);
	effCharge = CoreValency+(Z-CoreValency)*exp(-a1*r)-r*(a3+a4*r)*exp(-a2*r);
	// corePotU
	res = effCharge / r - alphaD/(2*pow(r,4)) * (1-exp(-rovrc6));
	// centrifugal
	res += hfL2 / (mu*r*r);
	if(j<0) // SOC ignored
		return res;
	ddrEffCharge = -a1*(Z-CoreValency)*exp(-a1*r) - ((a3+2*a4*r) - a2*r*(a3+a4*r))*exp(-a2*r);
	xi = effCharge/(r*r) -ddrEffCharge/r;
	aCovr5 = alphaD/(pow(r,5));
	xi += aCovr5 * (exp(-rovrc6)*(3*rovrc6-2)+2);
	xi /= r;
	return res + 0.5*alpha2*SoL*xi;
}

double xEffPot(double r){
	return radEffPot(r)+3/(32*mu*r*r);
}

void doMesh(Vec<double> & r_){
	xmin = dx;
	dx2t2o3 = dx*dx*2/3;
	int nsam = (int)((sqrt(rmax)-dx)/dx);
	if(nsam<=0){
		std::exit(-2);
	}
	n_samp = (size_t)nsam;
	r_.resiz(n_samp);
	double xt;
	for(size_t i=0; i<n_samp; i++){
		xt = xmin + i*dx;
		r_[i] = xt*xt;
	}
	return;
}

void initXPot(const Vec<double> & r_, Vec<double> & xpot_, Vec<double> * ebound_ = NULL){
	xpot_.resiz(n_samp);
	size_t i=0;
	if(ebound_!=NULL){
		ebound_->resiz(2);
		double elw, eup, et;
		elw = eup = xpot_[i] = xEffPot(r_[i]);
		for(i=1;i<n_samp;i++){
			et = xpot_[i] = xEffPot(r_[i]);
			if(et<elw) elw = et;
			if(et>eup) eup = et;
		}
		(*ebound_)[0] = elw;
		(*ebound_)[1] = eup;
		return;
	}
	for(i=0; i<n_samp; i++)
		xpot_[i] = xEffPot(r_[i]);
}

void initVecF(const Vec<double> & r_, const Vec<double> & xpot_, Vec<double> & f_){
	f_.resiz(n_samp);
	for(size_t i=0; i<n_samp; i++)
		f_[i] = 1- dx2t2o3*mu*r_[i]*xpot_[i];
}

double eigen(const size_t & L, const double & J, double Einit, double _a1, double _a2, double _a3, double _a4, double _rc){
	/*
	with x=\sqrt{r}, y(x)=x^{3/2}R(x^2), solve
		\frac{d^2 y(x)}{dx^2} = -g(x) y(x)
			g(\sqrt{r}) = 8r\mu(E-Veff(r))-\frac{3}{4r}
		with Numerov algorithm
	*/
	l = L;
	j = J;
	SoL=0.5*(j*(j+1)-l*(l+1)-0.75), hfL2=0.5*l*(l+1);
	a1 = _a1;
	a2 = _a2;
	a3 = _a3;
	a4 = _a4;
	rc = _rc;

	Vec<double> r_, xpot_, f_;
	// std::cout<<"Do Mesh\n";
	doMesh(r_);
	// std::cout<<"X Pot\n";
	initXPot(r_, xpot_);
	// std::cout<<"Fvec\n";
	initVecF(r_, xpot_, f_);

	Triband<double> A(n_samp);
	Triband<double> M(n_samp);
	size_t k=0;
	double rk=r_[k], eval;
	M.d.setAll(10.);
	A.d[k] = (12-10*f_[k])/rk; A.pu[k] = f_[k+1]/rk;
	M.pu[k]= r_[k+1]/rk;
	for(k++; k<n_samp-1; k++){
		rk = r_[k];
		A.pd[k-1] = f_[k-1]/rk; A.d[k] = (12-10*f_[k])/rk; A.pu[k] = f_[k+1]/rk;
		M.pd[k-1] = r_[k-1]/rk; M.pu[k] = r_[k+1]/rk;
	}
	rk = r_[k];
	A.pd[k-1] = f_[k-1]/rk; A.d[k] = (12-10*f_[k])/rk;
	M.pd[k-1] = r_[k-1]/rk;

	Vec<double> v(n_samp);
	// std::cout<<"Inverse Power Method"<<std::endl;
    // std::cout<<A.d;

	eval = invPower(A, v, M, -mu*dx2t2o3*Einit, 1e-10);
	
	A.destruct();
	M.destruct();
	r_.destruct();
	xpot_.destruct();
	f_.destruct();
	v.destruct();

	return -eval/(mu*dx2t2o3);
}

template <typename T1>
T1 maxbar(const Vec<T1> & v){
    T1 res = 0;
    for(size_t i=0; i< v.siz(); i++){
        if(abs(v[i]) > abs(res)) res = v[i];
    }
    return res;
}

template <typename T1>
T1 maxabs(const Vec<T1> & v){
    T1 res = 0, tmp;
    for(size_t i=0; i< v.siz(); i++){
        if((tmp=abs(v[i])) > res) res = tmp;
    }
    return res;
}

double invPower(const Triband<double> & T, Vec<double> & V, const Triband<double> & TM, double eval0, double rtol){
    // The eigenvalue in the vicinity of eval0 will be returned
    // and the corresponding eigenvector will be stored in v
    double eigval=0;
    size_t n=T.dim(), niter=0, i;

    V.setAll(n, 1.);
    Vec<double> u(n), w(n);
    double dv_norm = 1., tmp;

    // Tc = T - e_est * M
    Triband<double> Tc(n);
    for(i=0; i<n-1; i++){
    	Tc.d[i] = T.d[i] - eval0*TM.d[i];
    	Tc.pd[i]= T.pd[i]- eval0*TM.pd[i];
    	Tc.pu[i]= T.pu[i]- eval0*TM.pu[i];
    }
	Tc.d[i] = T.d[i] - eval0*TM.d[i];

	// LU decompose Tc on site
    LUdcmp(Tc);
    // Now Tc is no longer T - e_est * M
    while(dv_norm>rtol){
        u = V;
        MVprod(TM,V,w);
        // std::cout<<maxabs(w)<<std::endl;
        LUsolve(Tc,w);
        // std::cout<<maxabs(w)<<std::endl;
        V.fromCMult(eigval = 1./maxbar(w), w);
        // std::cout<<V.norm()<<std::endl;
        // std::cout<<"deigval="<<eigval<<std::endl;
        dv_norm = 0.;
        for(i=0; i<n; i++)
            if( (tmp=abs(V[i]-u[i]))>dv_norm ) dv_norm=tmp;
        if(niter++>=INVPOW_MAXITER){
            std::cout<<"InvPow Warning: Reached Maxiter. "<<rtol<<" cannot be satisfied. ";
            std::cout<<"Finally |dv| = "<<dv_norm<<std::endl;
            return eigval+eval0;
        }
    }
    V /= V.norm();
//    cout<<"The while loop finished"<<endl;
    Tc.destruct();
    u.destruct();
    w.destruct();
    return eigval+eval0;
}

// double Loss(){
// 	unsigned i=0;
// 	double res=0, tmp=0;
// 		params_reg[3] = a4;
// 		params_reg[4] = rc;
// 		a1 += h_a1*director(sed);
// 		a2 += h_a2*director(sed);
// 		a3 += h_a3*director(sed);
// 		a4 += h_a4*director(sed);
// 		rc += h_rc*director(sed);
// 		los_ = Loss();
// 		if(los_ > los){
// 			if(threador(sed) < exp(-beta*(los_-los))){// the step is accepted with the probability exp(-\beta(E'-E))

// 			}
// 			else{ // recover to the last step
// 				a1 = params_reg[0];
// 				a2 = params_reg[1];
// 				a3 = params_reg[2];
// 				a4 = params_reg[3];
// 				rc = params_reg[4];
// 				stay_count++;
// 			}
// 		}
// 		else stay_count=0;
// 		if(stay_count > SIMANN_MAXITER/10)
// 	}
// 	return;
// }

// void readCaIILevels(size_t L, std::vector<double> & J, std::vector<double> & E, bool verbose){
// 	std::ifstream fp;
// 	char fname[30];
// 	sprintf(fname,"CaII_L%lu.csv",L);
// 	if(verbose) std::cout<<fname<<std::endl;
// 	fp.open(fname);
// 	std::string x;
// 	size_t sz;
// 	double tmp;
// 	if(fp.good()){
// 		getline(fp, x, '\n');
// 		while(!fp.eof()){
// 			getline(fp, x, ',');
// 			getline(fp, x, ',');
// 			if(fp.eof()) break;
// 			tmp = std::stod(x,&sz);
// 			if(verbose) std::cout<<tmp<<'\t';
// 			J.push_back(tmp);
// 			getline(fp, x, ',');
// 			getline(fp, x, '\n');
// 			tmp = std::stod(x,&sz);
// 			if(verbose) std::cout<<tmp<<'\n';
// 			E.push_back(tmp);
// 		}
// 	}
// 	else{
// 		if(verbose) std::cout<<"IO Error"<<std::endl;
// 	}
// 	fp.close();
// }

static PyObject * numerovError;

static PyMethodDef module_methods[] = {
  // "Python name", C function,  arg_representation, doc
  {"eigE", (PyCFunction)NumerovEigE, METH_VARARGS,"Returns eigen energy near to an estimate energy"}
};

#if PY_MAJOR_VERSION >= 3
  static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT, "numerov",
    "Numerov method for the single electron in a central potential by a full-shell nuclei",
     -1, module_methods, NULL, NULL, NULL, NULL, };

  PyMODINIT_FUNC PyInit_numerov(void) {
    PyObject * m;
    m = PyModule_Create(&moduledef);
    if (m == NULL) return NULL;
    // import Numpy API
    import_array();
    //  creating numerovError
    numerovError = PyErr_NewException("numerov.error", NULL, NULL);
    Py_INCREF(numerovError);
    PyModule_AddObject(m, "error", numerovError);
    return m;
  }
#else
  PyMODINIT_FUNC initnumerov(void) {
    PyObject * m;
    m = Py_InitModule3("numerov", module_methods, "Numerov method for the single electron in a central potential by a full-shell nuclei");
    if (m == NULL) return;
    //  import Numpy API
    import_array();
    //  creating numerovError
    numerovError = PyErr_NewException("numerov.error", NULL, NULL);
    Py_INCREF(numerovError);
    PyModule_AddObject(m, "error", numerovError);
  }
#endif