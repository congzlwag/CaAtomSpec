#pragma once
// Linear algebra vector
//#include <stddef.h>
//#include "Mat.h"
//#include "tridiag.h"
#include <iostream>
//#include "myvector.h"
#include <vector>
#include <cmath>
// using namespace std;
// T should be long, double or complex<double>
// typedef complex<double> CDOUBLE;
typedef double DataType;

template <typename T>
class Vec: protected std::vector<T>
{
public:
    Vec(): std::vector<T>(){}
    Vec(const size_t & m): std::vector<T>(m){}
    Vec(const size_t & m, const T & x): std::vector<T>(m, x){}
    Vec(const Vec & v1): std::vector<T>(v1){}
    size_t siz() const {return std::vector<T>::size();}
    void resiz(const size_t & nn){std::vector<T>::resize(nn);}
    T & operator [] (size_t i){return std::vector<T>::operator [](i);}
    const T & operator [] (size_t i) const {return std::vector<T>::operator [](i);}
    void operator = (const Vec & mv){std::vector<T>::operator =(mv);}
    void setAll(const size_t & n, const T & x){std::vector<T>::assign(n, x);}
    void setAll(const T & x){std::vector<T>::assign(this->size(), x);}

    template <typename T1>
    void operator +=  (const Vec<T1> & x){
        if(x.siz()==this->siz()) for(size_t k=0; k<this->siz(); k++) (*this)[k] += x[k];
        else std::cout<<"Error: incompatible shape"<<std::endl;
    }
    template <typename T1>
    void operator -= (const Vec<T1> & x){
        if(x.siz()==this->siz()) for(size_t k=0; k<this->siz(); k++) (*this)[k] -= x[k];
        else std::cout<<"Error: incompatible shape"<<std::endl;
    }
    template <typename T1>
    void operator *= (const T1 & x){
        for(size_t k=0; k<this->siz(); k++) (*this)[k] *= x;
    }
    template <typename T1>
    void operator /= (const T1 & x){
        for(size_t k=0; k<this->siz(); k++) (*this)[k] /= x;
    }
    template <typename T1>
    void fromCopy(const Vec<T1> & v){
        size_t n;
        if(this->siz()!=(n=v.siz())) this->resiz(n);
        for(size_t k=0; k<n; k++) (*this)[k] = (v[k]);
    }
    template <typename T1, typename T2>
    void fromCMult(const T1 & c, const Vec<T2> & v){
        size_t n;
        if(this->siz()!=(n=v.siz())) this->resiz(n);
        for(size_t k=0; k<n; k++) (*this)[k] = (c*v[k]);
    }
    template <typename T1, typename T2>
    void fromCDivd(const T1 & c, const Vec<T2> & v){
        size_t n;
        if(this->siz()!=(n=v.siz())) this->resiz(n);
        for(size_t k=0; k<n; k++) (*this)[k] = (v[k]/c);
    }
    template <typename T1, typename T2>
    void fromVPlus(const Vec<T1> & v1, const Vec<T2> & v2){
        size_t n;
        if((n=v1.siz())==v2.siz()){
            if(this->siz()!=n) this->resiz(n);
            for(size_t k=0; k<n; k++) (*this)[k] = v1[k]+v2[k];
        }
        else std::cout<<"Error: incompatible shape"<<std::endl;
    }
    template <typename T1>
    T dot(const Vec<T1> & v1) const{
        T res =0;
        size_t n;
        if((n=v1.siz())==this->siz())
            for(size_t k=0; k<n; k++)
                res += (*this)[k]*v1[k];
        else std::cout<<"Error: incompatible shape"<<std::endl;
        return res;
    }
    DataType norm() const{
        DataType res=0;
        for(size_t p=0; p<(this->siz()); p++)
            res += pow(abs((*this)[p]), 2);
        return sqrt(res);
    }
    friend std::ostream & operator<<(std::ostream & os, const Vec & v){
        size_t n = v.siz();
        for(size_t p=0; p+1<n; p++)
            os<<v[p]<<",";
        os<<v[n-1]<<std::endl;
        return os;
    }
    ~Vec(){}
};

// template <typename T1>
// CDOUBLE hdot(const Vec<CDOUBLE> & a, const Vec<T1> & b){
//     CDOUBLE res = 0.0;
//     size_t n;
//     if((n=a.siz())==b.siz())
//         for(size_t k=0; k<n; k++) res += conj(a[k])*b[k];
//     return res;
// }

// void conjTo(Vec<CDOUBLE> & vdst, const Vec<CDOUBLE> & vsrc){
//     size_t n;
//     if((n=vsrc.siz())!=vdst.siz()) vdst.resiz(n);
//     for(size_t p=0; p<n; p++)
//         vdst[p] = conj(vsrc[p]);
// }

//void copyTo(Vec<CDOUBLE> & vdst, const Vec<DataType> & vsrc){
//    size_t n;
//    if((n=vsrc.siz())!=vdst.siz()) vdst.resiz(n);
//    for(size_t p=0; p<n; p++)
//        vdst[p] = vsrc[p];
//}

template <typename T1>
void ensure(Vec<T1> * & pv, size_t nn){
        if(pv!=NULL && pv->siz()!=nn){
            pv->resiz(nn);
        }
        if(pv==NULL)
            pv=new Vec<T1>(nn);
}
//template <class T>
//class Mat: public Bvec<
