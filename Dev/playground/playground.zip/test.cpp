#include <Python.h>
#define NPY_NO_DEPRECATED_API NPY_1_9_API_VERSION
#include <numpy/arrayobject.h>

#include <iostream>
#include <Vec.h>
static PyObject * Test(PyObject *self, PyObject *args);
static PyMethodDef module_methods[] = {
  // "Python name", C function,  arg_representation, doc
  {"test", (PyCFunction)Test, METH_VARARGS,"Playground function"}
};

#if PY_MAJOR_VERSION >= 3
  static struct PyModuleDef moduledef = {
    PyModuleDef_HEAD_INIT, "testa", "Testing Playground",
     -1, module_methods, NULL, NULL, NULL, NULL, };

  PyMODINIT_FUNC PyInit_testa(void) {
    // import Numpy API
    // import_array();
    return PyModule_Create(&moduledef);
  }
#else
  PyMODINIT_FUNC inittesta(void) {
    PyObject * m;
    m = Py_InitModule3("testa", module_methods, "Testing Playground");
    if (m == NULL) return;
    //  import Numpy API
    // import_array();
  }
#endif

static PyObject * Test(PyObject * self, PyObject * args){
	double x;
	if(!(PyArg_ParseTuple(args,"d",&x)))
		return NULL;
	Vec<double> v1(2,x);
	x = v1[0]+v1[1];
	return Py_BuildValue("d", x*x);
}
