# -*- coding: utf-8 -*-
from sys import path
path.append("./build/lib.linux-x86_64-3.6/")
from testa import test

if __name__ == '__main__':
	print(test(10.0))